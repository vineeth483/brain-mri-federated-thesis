# Brain MRI classification: federated learning thesis

Research code and selected results for centralized and federated four-class brain MRI image classification. This is an in-progress project.

## Current status

- The IID experiment used four simulated Flower clients and FedAvg over 20 rounds. The checkpoint selected by validation loss achieved 88.03% accuracy on 1,078 unique validation images. This is not a test-set result.
- IID and non-IID client assignments are recorded in `splits/`. Full non-IID training and matched evaluation remain to be completed.
- The earlier centralized MobileNetV2 result used a different split, so it is not directly comparable to the federated validation result.

## Repository contents

- `scripts/`: dataset audit, partitioning, centralized training, and federated training code.
- `splits/`: image manifests, IID and non-IID assignments, and audit summaries.
- `outputs/flower_iid_full/`: selected IID checkpoint, exact initial weights, validation history, configuration, and per-client round records.
- `outputs/trained_mobilenetv2/`: centralized MobileNetV2 checkpoint and recorded metrics.
- `outputs/trained_efficientnet_b0/`: metrics from a locally trained exploratory model.
- `requirements-mac-flower.txt`: direct dependencies for the Apple Silicon Flower environment. Additional packages may be needed for some earlier evaluation scripts.

The MRI dataset and virtual environments are not included. Paths in the manifests expect a `data/` folder. Source: [Brain Tumor MRI Dataset](https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset). Check the dataset terms before obtaining or redistributing it.

Model checkpoints are binary research artifacts. Do not interpret these models as clinically validated diagnostic tools.
